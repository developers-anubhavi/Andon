const express = require('express');
const bcrypt = require('bcrypt');
const {poolPromise,sql} = require('../MK1/db');
const router = express.Router();

router.post("/logout", async (req, res) => {
  try {
    const username = req.body?.username;

     if (!username) {
      console.warn("Logout called without username");
      return res.json({ success: true });
    }

    // console.log("LOGOUT from:", username);

    const pool = await poolPromise;

    await pool.request()
      .input("username", sql.VarChar, username)
      .query(`
        UPDATE ANDON_USER_LOGIN
        SET STATUS = 'INACTIVE'
        WHERE USERNAME = @username
      `);

    res.json({ success: true });

  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({ error: "Logout failed" });
  }
});

router.post("/logout", async (req, res) => {
  try {
    let username;

    if (typeof req.body === "string") {
      const data = JSON.parse(req.body);
      username = data.username;
    } else {
      username = req.body.username;
    }

    if (!username) {
      return res.status(400).json({ error: "Username missing" });
    }

    // console.log("LOGOUT from:", username);

    const pool = await poolPromise; 

    await pool.request()
      .input("username", sql.VarChar, username)
      .query(`
        UPDATE ANDON_USER_LOGIN
        SET STATUS = 'INACTIVE'
        WHERE USERNAME = @username
      `);

    return res.json({ success: true });

  } catch (error) {
    console.error("Logout error:", error);
    return res.status(500).json({ error: "Logout failed" });
  }
});

module.exports = router;
