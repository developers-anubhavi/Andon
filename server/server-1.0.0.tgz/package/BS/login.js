const express = require('express');
const bcrypt = require('bcrypt');
const {poolPromise,sql} = require('../BS/db');
const router = express.Router();

router.post("/bs_login", async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: "Username & Password required" });
        }

        const pool = await poolPromise;

        const result = await pool.request()
            .input("username", sql.VarChar, username)
            .query(`
                SELECT TOP 1 *
                FROM ANDON_USER_LOGIN
                WHERE USERNAME = @username COLLATE Latin1_General_CS_AS
            `);

        if (result.recordset.length === 0) {
            return res.status(401).json({ field: "username", message: "Invalid username" });
        }

        const user = result.recordset[0];
        const isPasswordMatch = await bcrypt.compare(password, user.PASSWORD);

        if (!isPasswordMatch) {
            return res.status(401).json({ field: "password", message: "Invalid password" });
        }

        if (user.STATUS === "ACTIVE") {
            return res.status(403).json({
                field: "status",
                message: "User already logged in on another device"
            });
        }

        await pool.request()
            .input("username", sql.VarChar, username)
            .query(`
                UPDATE ANDON_USER_LOGIN
                SET STATUS = 'ACTIVE'
                WHERE USERNAME = @username
            `);

        res.json({
            message: "Login successful",
            username: user.USERNAME,
            usertype: user.USERTYPE
        });

    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ message: "Server error" });
    }
});

router.post("/bs_logout", async (req, res) => {
  try {
    let username;

    if (typeof req.body === "string") {
      const data = JSON.parse(req.body);
      username = data.username;
    } else {
      username = req.body.username;
    }

    if (!username) {
      return res.status(400).json({ error: "Username missing" });
    }

    // console.log("LOGOUT from:", username);

    const pool = await poolPromise; 

    await pool.request()
      .input("username", sql.VarChar, username)
      .query(`
        UPDATE ANDON_USER_LOGIN
        SET STATUS = 'INACTIVE'
        WHERE USERNAME = @username
      `);

    return res.json({ success: true });

  } catch (error) {
    console.error("Logout error:", error);
    return res.status(500).json({ error: "Logout failed" });
  }
});

module.exports = router;
